
export const SET_SCREEN = 'SET_SCREEN';
export const SET_USER = 'SET_USER';
