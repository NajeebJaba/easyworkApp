export const LOGIN_SCREEN = 'LOGIN_SCREEN';
export const USER_SCREEN = 'USER_SCREEN';
export const NEW_WORKER = 'NEW_WORKER';
export const COMPLAINTS = 'COMPLAINTS';
export const NEW_SCHED = 'NEW_SCHED';
export const NEW_COMP = 'NEW_COMP';
export const MY_SCHED = 'MY_SCHED';